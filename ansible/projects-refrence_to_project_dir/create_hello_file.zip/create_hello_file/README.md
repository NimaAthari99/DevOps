# Create Hello File Project

## Table Of Contents
- [Inventory Description](#inventory-description)
    1) [Machines Details](#machines-details)
- [Variables Details](#variables-details)
    1. [Group Variables](#group-variables)
    2. [Host Variables](#host-variables) 

---

For all projects, first check your configurations are correct and dont have any error. For that, execute this commaand on your computer and replace your server's IP address with *'YOU_SERVER_IP'*.
```bash
ansible YOU_SERVER_IP -m ping
```

If didnt get any error and output is somthing like image below,  your configuration is ok and ready to continue!

---

### Inventory Description
#### Machines Details
File is configured and detailed in **"CHANGE_ME/inventory/README.md"** .

There is 1 group nima_servers. We have 2 machines; **`Hello_VM_1`** and **`Hello_VM_2`**. Because we just want to create a file and open it, we have 2 debian 13 with 1 core and 2GB ram as it is below:

| CPU           | RAM        | STORAGE     |
|---------------|------------|-------------|
| `2 Cores`     | `2 GB`     | `10 GB`     |

***[🔝 Table Of Contents](#table-of-contents)***

---

### Variables Details
#### Group Variables
There are some variables in project. "packages" which is located in "https://github.com/NimaAthari99/Linux/blob/main/ansible/projects/web-db-practice/inventory/group_vars/all/packages.yml" , are used for all 3 machine groups. Have 2  other variables called "certs" & "domain" located in "https://github.com/NimaAthari99/Linux/tree/main/ansible/projects/web-db-practice/inventory/group_vars/web_servers" . 

#### Host Variables
Here are variables for all hosts based on each. For example we have name of each machine in hosts.yml .

***[🔝 Table Of Contents](#table-of-contents)***

---

### Important Note
***Some Projects maay need spectaculer version of ansible. You need to search and find out what version shoud be installed, configured and to be used.***

***[🔝 Table Of Contents](#table-of-contents)***
